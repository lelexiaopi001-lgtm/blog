<?php /* 站点设置 */ ?>
<div class="panel">
    <div class="panel-head"><h3><?= adminIcon('i-settings') ?> 站点设置</h3></div>
    <form method="post" action="/admin/index.php?r=settings_save" class="stack-form settings-form">
        <?= Helper::csrfField() ?>

        <div class="form-section">基本信息</div>
        <div class="form-row">
            <label>站点名称</label>
            <input class="input" type="text" name="site_name" value="<?= Helper::e($all['site_name'] ?? '') ?>">
        </div>
        <div class="form-row">
            <label>站点描述</label>
            <input class="input" type="text" name="site_desc" value="<?= Helper::e($all['site_desc'] ?? '') ?>">
        </div>
        <div class="form-row">
            <label>签名 / Slogan（首页大标题下方展示）</label>
            <input class="input" type="text" name="site_slogan" value="<?= Helper::e($all['site_slogan'] ?? '') ?>" placeholder="如：Stay curious, keep writing.">
        </div>
        <div class="form-row">
            <label>名言 / Motto（首页签名下方展示）</label>
            <input class="input" type="text" name="site_motto" value="<?= Helper::e($all['site_motto'] ?? '') ?>" placeholder="如：「用文字点亮极光」">
        </div>
        <div class="form-row">
            <label>首页顶部欢迎语（小字标签）</label>
            <input class="input" type="text" name="site_hero_eyebrow" value="<?= Helper::e($all['site_hero_eyebrow'] ?? '') ?>" placeholder="如：✦ Welcome to my space">
        </div>
        <div class="form-row">
            <label>SEO 关键词</label>
            <input class="input" type="text" name="site_keywords" value="<?= Helper::e($all['site_keywords'] ?? '') ?>">
        </div>
        <div class="form-row">
            <label>ICP 备案号（留空不显示）</label>
            <input class="input" type="text" name="site_icp" value="<?= Helper::e($all['site_icp'] ?? '') ?>" placeholder="如：京ICP备00000000号">
        </div>
        <div class="form-row">
            <label>页脚文字</label>
            <input class="input" type="text" name="footer_text" value="<?= Helper::e($all['footer_text'] ?? '') ?>">
        </div>

        <div class="form-section">头像与 Logo</div>
        <div class="form-row">
            <label>头像 URL（关于页展示）</label>
            <input class="input" type="text" name="site_avatar" id="sAvatar" value="<?= Helper::e($all['site_avatar'] ?? '') ?>" placeholder="https://…">
            <label class="btn btn-xs upload-inline"><?= adminIcon('i-upload', 'icon-sm') ?> 上传<input type="file" accept="image/*" data-target="sAvatar" hidden></label>
        </div>
        <div class="form-row">
            <label>Logo URL</label>
            <input class="input" type="text" name="site_logo" value="<?= Helper::e($all['site_logo'] ?? '') ?>" placeholder="https://…">
        </div>

        <div class="form-section">社交链接</div>
        <div class="form-row">
            <label>GitHub</label>
            <input class="input" type="url" name="site_social_github" value="<?= Helper::e($all['site_social_github'] ?? '') ?>">
        </div>
        <div class="form-row">
            <label>Twitter / X</label>
            <input class="input" type="url" name="site_social_twitter" value="<?= Helper::e($all['site_social_twitter'] ?? '') ?>">
        </div>
        <div class="form-row">
            <label>联系邮箱</label>
            <input class="input" type="email" name="site_social_email" value="<?= Helper::e($all['site_social_email'] ?? '') ?>">
        </div>

        <div class="form-section">关于页内容（Markdown）</div>
        <div class="form-row">
            <textarea class="input" name="site_about" rows="8" placeholder="关于我…"><?= Helper::e($all['site_about'] ?? '') ?></textarea>
        </div>

        <div class="form-section">评论与显示</div>
        <div class="form-row two-inline">
            <div>
                <label>评论功能</label>
                <select class="input" name="comment_switch">
                    <option value="1" <?= ($all['comment_switch'] ?? '1') === '1' ? 'selected' : '' ?>>开启</option>
                    <option value="0" <?= ($all['comment_switch'] ?? '1') !== '1' ? 'selected' : '' ?>>关闭</option>
                </select>
            </div>
            <div>
                <label>评论审核</label>
                <select class="input" name="comment_audit">
                    <option value="1" <?= ($all['comment_audit'] ?? '1') === '1' ? 'selected' : '' ?>>需要审核后显示</option>
                    <option value="0" <?= ($all['comment_audit'] ?? '1') !== '1' ? 'selected' : '' ?>>直接显示</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <label>每页文章数</label>
            <input class="input" type="number" name="page_size" value="<?= Helper::e($all['page_size'] ?? '10') ?>" min="1" max="50">
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit"><?= adminIcon('i-save', 'icon-sm') ?> 保存设置</button>
        </div>
    </form>
</div>
